﻿namespace WpfApp6
{
    internal class DiscordViewModel
    {
        public DiscordViewModel()
        {
        }

        public string DiscordUsername { get; internal set; }
        public string DiscordAvatar { get; internal set; }
    }
}