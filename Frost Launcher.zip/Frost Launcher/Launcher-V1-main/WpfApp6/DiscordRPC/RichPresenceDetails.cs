﻿using Frost;

namespace WpfApp6
{
    internal class RichPresenceDetails
    {
        public string Details { get; internal set; }
        public string State { get; internal set; }
        public Assets Assets { get; internal set; }
    }
}