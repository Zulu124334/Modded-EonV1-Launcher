﻿using Frost;

internal class RichPresence
{
    public string Details { get; internal set; }
    public string State { get; internal set; }
    public Assets Assets { get; internal set; }
    public Timestamps Timestamps { get; internal set; }
}