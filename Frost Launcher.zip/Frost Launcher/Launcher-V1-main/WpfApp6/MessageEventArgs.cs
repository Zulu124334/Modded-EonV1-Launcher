﻿namespace Frost
{
    internal class MessageEventArgs
    {
        public object Message { get; internal set; }
    }
}