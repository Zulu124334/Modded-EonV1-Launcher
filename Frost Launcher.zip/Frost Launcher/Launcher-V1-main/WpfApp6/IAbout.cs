﻿namespace Frost
{
    public interface IAbout
    {
        void InitializeComponent();
    }
}