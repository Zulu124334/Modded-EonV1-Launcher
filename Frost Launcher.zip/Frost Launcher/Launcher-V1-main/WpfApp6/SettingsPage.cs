﻿namespace WpfApp6
{
    internal class SettingsPage
    {
        public SettingsPage()
        {
        }
    }
}