﻿namespace WpfApp6
{
    internal class HomePage
    {
        public HomePage()
        {
        }
    }
}